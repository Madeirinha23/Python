package com.example.projeto_mvp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
